// 알림 유형 enum
public enum NotificationType {
    APPLY,    // 지원
    ACCEPT,   // 수락
    REJECT,   // 거절
    MESSAGE   // 메시지
}
